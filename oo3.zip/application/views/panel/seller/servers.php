<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Server VPN SSH
      </h1>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
        <li class="active">เซิร์ฟเวอร์ทั้งหมด</li>
    </ol>
    </section>
    		<section class="content">
   			 <div class="row">
                    <div class="col-md-12 text-center">
                        <label class="label label-success">Fast Data Transfer</label>
                        <label class="label label-warning">High Speed Servers</label>
                        <label class="label label-info">Hide Your IP</label>
                        <label class="label label-primary">Premium VPN Server</label>
                        <label class="label label-warning">Worldwide Servers</label>
                        <label class="label label-success">Internet Privacy</label>
                        <label class="label label-info">Exclusive Secure Shell</label>
                        <label class="label label-primary">Security Solutions</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 text-center">
                        <label class="label label-danger">No DDOS</label>
                        <label class="label label-danger">No BUG</label>
                        <label class="label label-danger">No Hacking</label>
                        <label class="label label-danger">No Carding</label>
                        <label class="label label-danger">No Spamm</label>
                        <label class="label label-danger">No Torrent</label>
                        <label class="label label-danger">No Fraud</label>
                        <label class="label label-danger">No Error</label>
                        <label class="label label-danger">No Repost</label>
                    </div>
                </div>
			<br>
    
    <div class="row">
        <div class="col-md-6">            
            <div class="dropdown pull-right">
				<button style="font-size: 16px;" class="badge bg-maroon btn-outline-danger my-2 my-lg-5" type="button"><span class="fa fa-btc"></span>  ยอดเงินคงเหลือ : <?php echo  $user->saldo ?> บาท</button>
				 
				<button style="font-size: 16px;" class="badge bg-purple btn-outline-danger my-2 my-lg-5 dropdown-toggle" type="button" data-toggle="dropdown"><span class="fa fa-plus fa-fw"></span> เติมเงิน </button>
           
				<ul class="dropdown-menu">
					<li class="active"><a href="<?php echo  base_url('panel/reseller/'.str_replace(' ','-',$_SESSION['username']).'/topup') ?>">TRUE WALLET เลขอ้างอิง</a></li>
					<li><a href="<?php echo  base_url('panel/reseller/'.str_replace(' ','-',$_SESSION['username']).'/topups') ?>">TRUE MONEY WALLET</a></li>
				</ul>
            </div>            
        </div>
    </div>
 <br>
        <div class="row">
            <div class="col-sm-6 col-md-4 col-lg-3">
                <?php if (isset($message)) {echo $message; }?>
            </div>
        <?php foreach($server as $row): ?>
		
       <div class="col-sm-6 col-md-4 col-lg-3">    
        <div class="box box-widget widget-user">
           <div class="widget-user-header bg-black" style="background: url('<?php echo  base_url('asset/img/s4.png') ?>') center center;">
              <h3 class="widget-user-username"><B><?php echo  $row['ServerName']?><B></h3>
              <h4 class="widget-user-desc"><B><?php echo  $row['Expired']?> วัน <?php echo  $row['Price']?> บาท <B></h4>
              <?php if ($row['Status']) { echo '';} else {echo "เต็ม";}?>
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="<?php echo  base_url('asset/img/user.png') ?>" alt="User Avatar">
            </div>
                  
       <div class="box-footer no-padding">
      	<div class="description-block"><br><br>
            <span class="description-text"><span style="font-size: 16px;"  class="badge bg-red">รายละเอียด</span></span>
         </div>
         
              <ul class="nav nav-stacked">
                <li><a href="#"><B> เซิร์ฟเวอร์ </B><span class="pull-right">IP HOST</span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-aqua"><?php echo  $row['Location']?></span> <span style="font-size: 16px;" class="pull-right badge bg-purple">แสดงเมื่อเช่าแล้ว</span></a></li>
                
                <li><a href="#"> PORT <span class="pull-right">จำกัดเชื่อมต่อ</span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-maroon"><?php echo  $row['OpenSSH']?>, <?php echo  $row['Dropbear']?></span><span style="font-size: 16px;" class="pull-right badge bg-navy">VPN <?php echo  $row['limitvpn']?> SSH <?php echo  $row['limitssh']?></span></a></li>
                
                <li><a href="#"> วันใช้งาน <span class="pull-right"> จำกัด </span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-purple"><?php echo  $row['Expired']?> วัน </span><span style="font-size: 16px;" class="pull-right badge bg-blue"><?php echo  $row['MaxUser']?> บัญชี/วัน </span></a></li>
                
                <li><a href="#"> ราคา <span class="pull-right"> สถานะเซิร์ฟเวอร์ </span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-orange"><?php echo  $row['Price']?> บาท </span><span style="font-size: 16px;" class="pull-right badge bg-green"> <?php if ($row['Status']) { echo 'Online';} else {echo "Offline";}?></span></a></li>
                
              </ul>
            </div>
						 
                    <div class="box-footer text-center">
                    	<button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#<?php echo  $row['Id']?>"><i class="fa fa-mixcloud"></i>
  เลือกเช่า
						</button>
                        
                        <a href="<?php echo  base_url('web/vpn/'.str_replace(' ','-',$row['configvpn']).' ') ?>" class="btn btn-sm btn-warning"><i class="fa fa-cloud-download"></i>ไฟล์ VPN</a>
                        <a href="<?php echo  base_url('web/http/'.str_replace(' ','-',$row['configssh']).' ') ?>" class="btn btn-sm btn-info"><i class="fa fa-cloud-upload"></i>ไฟล์ SSH</a>
                    </div>
                                        
<div class="modal fade" id="<?php echo  $row['Id']?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">ข้อควรจำ!!!</h4>
      </div>
      <div class="modal-body">
        รายละเอียดของเซิร์ฟเวอร์ คือ วันใช้งานของบัญชี เป็นไปตามที่กำหนด  และสำหรับการเชื่อมต่อ คือ VPN 1 และ SSH 2 สรุป 1 บัญชีที่ท่านเช่าไปสำหรับเซิร์ฟเวอร์นี้ สามารถ ใช้งานเชื่อมต่อได้ พร้อมกัน 3 เครื่อง หาก เชื่อมต่อ SSH 3 เครื่อง บัญชีของท่านจะถูกแบนทันที และทางเว็บจะไม่ปลดล็อคให้ ไม่ว่ากรณีใดๆ เพราะถือว่าเราได้แจ้งไว้ชัดเจนแล้ว ก่อนที่ท่านจะเลือกเช่าไปใช้งาน ที่ระบุไว้ข้างต้น ท่านอ่านและทำความเข้าใจแล้ว 
      </div>
      <div class="modal-footer">
        <a href="<?php echo  base_url('main/seller/'.$_SESSION['username'].'/buy/'.str_replace(' ','-',$row['ServerName']).'/'.$row['Id']) ?>" class="btn btn-info"><i class="fa fa-shopping-cart fa-fw"></i> ยืนยันเช่า</a>
        <button type="button" class="btn btn-danger btn-simple" data-dismiss="modal">ยกเลิก</button>
      </div>
    </div>
  </div>
</div>
                    
                    
                    
                </div>
            </div>
        <?php endforeach; ?>
    </div>     
    </section>
</div>