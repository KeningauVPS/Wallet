<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Server VPN SSH
      </h1>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
        <li class="active">เซิร์ฟเวอร์ทั้งหมด</li>
    </ol>
    </section>
    		<section class="content">
   			 <div class="row">
                    <div class="col-md-12 text-center">
                        <label class="label label-success">Fast Data Transfer</label>
                        <label class="label label-warning">High Speed Servers</label>
                        <label class="label label-info">Hide Your IP</label>
                        <label class="label label-primary">Premium VPN Server</label>
                        <label class="label label-warning">Worldwide Servers</label>
                        <label class="label label-success">Internet Privacy</label>
                        <label class="label label-info">Exclusive Secure Shell</label>
                        <label class="label label-primary">Security Solutions</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 text-center">
                        <label class="label label-danger">No DDOS</label>
                        <label class="label label-danger">No BUG</label>
                        <label class="label label-danger">No Hacking</label>
                        <label class="label label-danger">No Carding</label>
                        <label class="label label-danger">No Spamm</label>
                        <label class="label label-danger">No Torrent</label>
                        <label class="label label-danger">No Fraud</label>
                        <label class="label label-danger">No Error</label>
                        <label class="label label-danger">No Repost</label>
                    </div>
                </div>
			<br>
    
    <div class="row">
        <div class="col-md-6">            
            <div class="dropdown pull-right">
				<button class="btn btn-outline-danger my-2 my-sm-0 dropdown-toggle" type="button" data-toggle="dropdown"><span class="fa fa-plus fa-fw"></span> เติมเงิน </button>
				    
            <div class="btn btn-warning"> ยอดเงินคงเหลือ : <a><?php echo  $user->saldo ?></a></div>         
				<ul class="dropdown-menu">
					<li class="active"><a href="<?php echo  base_url('panel/reseller/'.str_replace(' ','-',$_SESSION['username']).'/topup') ?>">TRUE WALLET เลขอ้างอิง</a></li>
					<li><a href="<?php echo  base_url('panel/reseller/'.str_replace(' ','-',$_SESSION['username']).'/topups') ?>">TRUE MONEY WALLET</a></li>
				</ul>
            </div>            
        </div>
    </div>
 <br>
        <div class="row">
            <div class="col-sm-6 col-md-4 col-lg-3">
                <?php if (isset($message)) {echo $message; }?>
            </div>
        <?php foreach($server as $row): ?>
		
       <div class="col-sm-6 col-md-4 col-lg-3">    
        <div class="box box-widget widget-user">
           <div class="widget-user-header bg-black" style="background: url('<?php echo  base_url('asset/img/photo1.jpg') ?>') center center;">
              <h3 class="widget-user-username"><?php echo  $row['ServerName']?></h3>
              <h5 class="widget-user-desc"><?php echo  $row['Expired']?> วัน</h5>
              <?php if ($row['Status']) { echo '';} else {echo "เต็ม";}?>
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="<?php echo  base_url('asset/img/user3-128x128.png') ?>" alt="User Avatar">
            </div>
                  
       <div class="box-footer">
	    <div class="description-block">
            <h5 class="description-header">เซิร์ฟเวอร์</h5>
            <span class="description-text"><span class="badge bg-red"><?php echo  $row['Location']?></span></span>
         </div>
           	
        <div class="description-block">
            <h5 class="description-header">IP HOST</h5>
            <span class="description-text"><span class="badge label-warning">แสดงเมื่อเช่าแล้ว</span></span>
         </div>
         
		<div class="description-block">
            <h5 class="description-header">Port</h5>
            <span class="description-text"><span class="badge label-info"><?php echo  $row['OpenSSH']?>, <?php echo  $row['Dropbear']?></span></span>
        </div>
        
        <div class="description-block">
            <h5 class="description-header">จำกัดเชื่อมต่อ</h5>
            <span class="description-text"><span class="badge label-success">VPN <?php echo  $row['limitvpn']?> SSH <?php echo  $row['limitssh']?> </span></span>
        </div>
        
        <div class="description-block">
            <h5 class="description-header">วันใช้งาน </h5>
            <span class="description-text"><span class="badge label-warning"><?php echo  $row['Expired']?> วัน</span></span>
        </div>
        
        <div class="description-block">
            <h5 class="description-header">จำกัด </h5>
            <span class="description-text"><span class="badge label-primary"><?php echo  $row['MaxUser']?> บัญชี/วัน</span></span>
        </div>
         
        
        <div class="description-block">
            <h5 class="description-header">ราคา </h5>
            <span class="description-text"><span style="font-size: 16px;" class="badge label-info"><?php echo  $row['Price']?> บาท</span> </span>
        </div>
        
        <div class="description-block">
            <h5 class="description-header">สถานะเซิฟ </h5>
            <span class="description-text"><span class="badge label-success"> <?php if ($row['Status']) { echo 'Online';} else {echo "Offline";}?></span></span>
        </div>
						 
                    <div class="box-footer text-center">
                        <a href="<?php echo  base_url('panel/seller/'.$_SESSION['username'].'/buy/'.str_replace(' ','-',$row['ServerName']).'/'.$row['Id']) ?>" class="btn btn-info"><i class="fa fa-shopping-cart fa-fw"></i> เลือกเช่าเซิฟนี้</a>
                        <a href="http://{{ @server->host }}/vpn-config.rar" class="btn btn-default"><i class="fa fa-download fa-fw"></i> VPN Config</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

     
    </section>
</div>