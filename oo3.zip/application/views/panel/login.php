<!doctype html>
<html>
 <head> 
  <meta charset="utf-8"> 
  <title>LOWCLASS VPN SSH</title> 
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 
  <meta name="robots" content="index,follow"> 
  <meta name="description" content="LOWCLASS VPN SSH lowclass-vpn.ga lowclass vpn ssh"> 
  <meta name="keywords" content="LOWCLASS VPN SSH lowclass-vpn.ga lowclass vpn ssh"> 
  <meta name="author" content="LOWCLASS"> 
  <!-- Favicons --> 
  <link rel="shortcut icon" href="<?php echo  base_url('shortcut icon" href="/favicon.ico" type="image/x-icon')?>"/>
  <link rel="shortcut icon" href="<?php echo  base_url('apple-touch-icon" href="/apple-touch-icon.png')?>"/>
  <link rel="shortcut icon" href="<?php echo  base_url('apple-touch-icon" sizes="57x57" href="/apple-touch-icon-57x57.png')?>"/>
  <link rel="shortcut icon" href="<?php echo  base_url('apple-touch-icon" sizes="72x72" href="/apple-touch-icon-72x72.png')?>"/>
  <link rel="shortcut icon" href="<?php echo  base_url('apple-touch-icon" sizes="76x76" href="/apple-touch-icon-76x76.png')?>"/>
  <link rel="shortcut icon" href="<?php echo  base_url('apple-touch-icon" sizes="114x114" href="/apple-touch-icon-114x114.png')?>"/>
  <link rel="shortcut icon" href="<?php echo  base_url('apple-touch-icon" sizes="120x120" href="/apple-touch-icon-120x120.png')?>"/>
  <link rel="shortcut icon" href="<?php echo  base_url('apple-touch-icon" sizes="144x144" href="/apple-touch-icon-144x144.png')?>"/>
  <link rel="shortcut icon" href="<?php echo  base_url('apple-touch-icon" sizes="152x152" href="/apple-touch-icon-152x152.png')?>"/>
  <link rel="shortcut icon" href="<?php echo  base_url('apple-touch-icon" sizes="180x180" href="/apple-touch-icon-180x180.png')?>"/>
  <meta property="fb:admins" content="100011502860799"> 
  <meta property="og:locale" content="en_US"> 
  <meta property="og:url" content="http://sshaiopremium.ga">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"> 
  <!-- Royal Preloader CSS --> 
  <link href="<?php echo  base_url('asset/login/css/material.min.css" type="text/css')?>" rel="stylesheet"/>
  <link href="<?php echo  base_url('asset/login/css/theme.css')?>" rel="stylesheet"/>
  <link href="<?php echo  base_url('asset/login/css/main.css')?>" rel="stylesheet"/>
  <link href="<?php echo  base_url('asset/login/css/css')?>" rel="stylesheet"/>
   
   <script src="<?php echo  base_url('plugins/login/parallax.min.js/') ?>"></script>
 </head> 
 <body class="mdl-demo mdl-base"> 
  <div class="mdl-layout mdl-js-layout mdl-layout--fixed-header"> 
   <div class="mdl-demo mdl-layout mdl-js-layout mdl-layout--fixed-drawer mdl-layout--fixed-header"> 
    <header class="mdl-layout__header"> 
     <div class="mdl-layout__header-row"> 
     	<?php foreach ($this->user_model->view_asset() as $row): ?>
      	<?php if (empty($row['rekening'])):?>
      	<?php if (empty($row['bank'])):?>
      	<?php if (empty($row['pemilik'])):?>
			<span class="mdl-layout-title"> <a class="site-header mdl-navigation__link--title" href="/"> <span class="microsite-name mdl-typography--font-light"><?php echo  $row['webname']?></span> </a> </span> 
  
<?php endif;?>
    <?php endif;?>
    	<?php endif;?>
			 <?php endforeach; ?>
      
      <input type="checkbox" id="site-nav-checkbox" class="visuallyhidden"> 
      <div class="top-nav-wrapper"> 
       <label for="site-nav-checkbox">MENU</label> 
       <nav class="mdl-navigation">
        <a class="mdl-navigation__link" href="/">LOGIN</a> 
       </nav> 
       <div class="mdl-layout-spacer"></div> 
       <nav class="mdl-navigation"> 
        <a class="mdl-navigation__link" href="/register">REGISTER</a> 
       </nav> 
      </div> 
     </div> 
    </header> 
    
      <header class="hero-background"> 
       <section class="hero-container section--center mdl-grid mdl-grid--no-spacing"> 
        <div class="mdl-cell mdl-cell--6-col-desktop mdl-cell--12-col-tablet mdl-cell--12-col-phone"> 
   <?php foreach ($this->user_model->view_asset() as $row): ?>
      <?php if (empty($row['rekening'])):?>
         <?php if (empty($row['bank'])):?>
      	   <?php if (empty($row['pemilik'])):?>
  			   <h4 class=""><?php echo  $row['webname']?></h4> 
					<?php endif;?>
    			<?php endif;?>
    		<?php endif;?>
	 <?php endforeach; ?>
         
         <h5 class="tagline">ยินดีต้อนรับ</h5> 
         <div class="login">    	   
   
<?php if (validation_errors()) : ?>
                    <div class="alert alert-danger"><?php echo  validation_errors() ?></div>
                <?php endif; ?>
                <?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?php echo  $error ?></div>
					</div>
				<?php endif; ?>
		
   			 <?php echo  form_open() ?>
                <fieldset>
            <div class="col-lg-12">
               <div class="form-group">
  				<span for="username">USERNAME</span>
		            <input class="form-control text-center" placeholder="ชื่อบัญชี" name="username" type="text" autofocus required>
	 			<span for="password">PASSWORD</span>
		            <input class="form-control text-center" placeholder="รหัสผ่าน" name="password" type="password" required>
				  </div>   
				<div class="form-group">
					<div class="button-container mdl-cell mdl-cell--12-col-desktop center"> 
      				<input  type="submit" value=" LOGIN " name="submit" class="cta-button mdl-typography--font-regular mdl-button mdl-button--raised mdl-button--accent">
      						</div>         		
						</div> 
					</div> 
					
  				</fieldset>    
			  </form>
		  </div>
        </div> 
   </section>
   <br><br>
   <br><br>
  <br><br>
  <br><br>
   <br><br>
  <br><br>
</header>      
     
  <script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
    ga('create', 'UA-8594346-15', 'auto');
    ga('send', 'pageview');
</script>   
 </body>
</html>