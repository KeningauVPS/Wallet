<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
             <section class="content-header">
      <h2>
       รายชื่อสมาชิก
      </h2>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
		<li class="active"> รายชื่อสมาชิก</li>
    </ol>
    </section>
  
		 <div class="row">
                    <div class="col-md-12 text-center">
                        <label class="label label-success">Fast Data Transfer</label>
                        <label class="label label-warning">High Speed Servers</label>
                        <label class="label label-info">Hide Your IP</label>
                        <label class="label label-primary">Premium VPN Server</label>
                        <label class="label label-warning">Worldwide Servers</label>
                        <label class="label label-success">Internet Privacy</label>
                        <label class="label label-info">Exclusive Secure Shell</label>
                        <label class="label label-success">Security Solutions</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 text-center">
                        <label class="label label-danger">No DDOS</label>
                        <label class="label label-danger">No Hacking</label>
                        <label class="label label-danger">No Carding</label>
                        <label class="label label-danger">No Spamm</label>
                        <label class="label label-danger">No Torrent</label>
                        <label class="label label-danger">No Fraud</label>
                        <label class="label label-danger">No Repost</label>                        
                    </div>
                </div>
                <p></p>
	          
<a href="/admin/delete_seller" class="btn btn-default pull-right" alt="hapus seller dengan saldo 0"><i class="fa fa-trash-o" aria-hidden="true"></i> Delete </a>
</h1>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <i class="fa fa-group fa-fw"></i> รายชื่อ
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>ชื่อ</th>
                                    <th>Email</th>
                                    <th>เครดิต</th>
                                    <th>วันสมัคร</th>
                                    <th>ลบ</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(!empty($msg)): ?>
                                        <?php foreach ($msg as $row): ?>
                                            <tr>
                                                <td><?php echo  $row['id'] ?></td>
                                                <td><?php echo  $row['username'] ?></td>
                                                <td><?php echo  $row['email']?></td>
												<td><?php echo  $row['saldo']?></td>
                                                <td><?php echo  $row['created_at']?></td>
                                                
                                                <td>
                                                    <a href="<?php echo  base_url('admin/delet_seller/'. $row['id'])?>" class="btn btn-default"><span class="fa fa-trash-o fa-sm"></span></a>
                                                </td>
                                             </tr>
                                       <?php endforeach; ?>
                                    <?php else: ?>
                                   
                                        <tr>
                                            <td class="text-muted text-center" colspan="6"> ไม่มีบัญชีที่สมัคร</td>
                                        </tr>
                                   <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>