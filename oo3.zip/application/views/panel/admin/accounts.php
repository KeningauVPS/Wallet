<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       รายชื่อคนเช่า
      </h1>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
        <li><a href="/"><i class="fa fa-server"></i> เซิร์ฟเวอร์</a></li>
		<il class="active"> <?php echo  $server -> HostName ?></li>
    </ol>
    </section>
    		<section class="content">
   			 <div class="row">
                    <div class="col-md-12 text-center">
                        <label class="label label-success">Fast Data Transfer</label>
                        <label class="label label-warning">High Speed Servers</label>
                        <label class="label label-info">Hide Your IP</label>
                        <label class="label label-primary">Premium VPN Server</label>
                        <label class="label label-warning">Worldwide Servers</label>
                        <label class="label label-success">Internet Privacy</label>
                        <label class="label label-info">Exclusive Secure Shell</label>
                        <label class="label label-primary">Security Solutions</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 text-center">
                        <label class="label label-danger">No DDOS</label>
                        <label class="label label-danger">No BUG</label>
                        <label class="label label-danger">No Hacking</label>
                        <label class="label label-danger">No Carding</label>
                        <label class="label label-danger">No Spamm</label>
                        <label class="label label-danger">No Torrent</label>
                        <label class="label label-danger">No Fraud</label>
                        <label class="label label-danger">No Error</label>
                        <label class="label label-danger">No Repost</label>
                    </div>
                </div>
			<br>            
    
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-danger">
                <div class="panel-heading">
                	<a href="<?php echo  base_url('seller/buy/'. $server->Id )?>" class="btn btn-default pull-right"><i class="fa fa-plus fa-fw"></i> เพิ่ม</a>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-hover" id="myTable">
                            <thead onmouseover="sortTable()">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>บัญชี</th>
                                    <th>คนเช่า</th>
                                    <th>วันที่เช่า</th>
                                    <th>วันหมด</th>
                                    <th>ลบ</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(!empty($user)): ?>
                                        <?php foreach ($user as $row): ?>
                                            <tr>
                                                <td><?php echo  $row['id'] ?></td>
                                                <td><?php echo  $row['username'] ?></td>
                                                <td><?php echo  $row['created_by']?></td>
                                                <td><?php echo  $row['created_at']?></td>
                                                <td><?php echo  $row['expired_at']?></td>
                                                <td>
                                                    <a href="<?php echo  base_url('admin/delet_account/'. $row['id'])?>" class="btn btn-danger"><span class="fa fa-trash-o fa-sm"></span></a>
                                                </td>
                                             </tr>
                                       <?php endforeach; ?>
                                    <?php else: ?>
                   
                                        <tr>
                                            <td class="text-muted text-center" colspan="6"> ยังไม่มีคนเช่า</td>
                                        </tr>
                                   <?php endif; ?>
                            </tbody>
                        </table>
<script>
function sortTable() {
  var table, rows, switching, i, x, y, shouldSwitch;
  table = document.getElementById("myTable");
  switching = true;
  /*Make a loop that will continue until
  no switching has been done:*/
  while (switching) {
    //start by saying: no switching is done:
    switching = false;
    rows = table.getElementsByTagName("TR");
    /*Loop through all table rows (except the
    first, which contains table headers):*/
    for (i = 1; i < (rows.length - 1); i++) {
      //start by saying there should be no switching:
      shouldSwitch = false;
      /*Get the two elements you want to compare,
      one from current row and one from the next:*/
      x = rows[i].getElementsByTagName("TD")[0];
      y = rows[i + 1].getElementsByTagName("TD")[0];
      //check if the two rows should switch place:
      if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
        //if so, mark as a switch and break the loop:
        shouldSwitch= true;
        break;
      }
    }
    if (shouldSwitch) {
      /*If a switch has been marked, make the switch
      and mark that a switch has been done:*/
      rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
      switching = true;
    }
  }
}
</script>
                    </div>
                </div>
            </div>
        </div>
    </div>

      </section>
</div>