<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        กิจกรรม และ โปรไฟล์
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Profile</li>
      </ol>
    </section>
   				
   <section class="content">
		<div class="row">
                    <div class="col-md-12 text-center">
                        <label class="label label-success">Fast Data Transfer</label>
                        <label class="label label-warning">High Speed Servers</label>
                        <label class="label label-info">Hide Your IP</label>
                        <label class="label label-primary">Premium VPN Server</label>
                        <label class="label label-warning">Worldwide Servers</label>
                        <label class="label label-success">Internet Privacy</label>
                        <label class="label label-info">Exclusive Secure Shell</label>
                        <label class="label label-success">Security Solutions</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 text-center">
                        <label class="label label-danger">No DDOS</label>
                        <label class="label label-danger">No Hacking</label>
                        <label class="label label-danger">No Carding</label>
                        <label class="label label-danger">No Spamm</label>
                        <label class="label label-danger">No Torrent</label>
                        <label class="label label-danger">No Fraud</label>
                        <label class="label label-danger">No Repost</label>                        
                    </div>
                </div>
                <p></p>
                
        <div class="box box-danger">
            <div class="box-header with-border">
               <i class="fa fa-cog fa-spin"></i><h3 class="box-title">เปลี่ยนรหัสผ่าน</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
        <div class="row">
        <div class="col-md-6">
			<?php if (isset($message)) {echo $message; }?>
			<?php if (isset($success)) {echo $success; }?>
            
              
                <div class="panel-body">
                    <form role="form" action="<?php echo  base_url('panel/'.$_SESSION['username'].'/setting')?>" method="POST">
						<input type="hidden" name="username" value="gakbisalahyaa">
                        <div class="form-group">
                            <label>Password</label>
                            <input class="form-control" placeholder="Password" name="passwold" type="password"  disabled required>
                        </div>
                        <div class="form-group">
                            <label>รหัสผ่านใหม่</label>
                            <input class="form-control" placeholder="New Password" name="password" type="password" required>
                        </div>
                        <div class="form-group">
                            <label>รหัสผ่านใหม่อีกครั้ง</label>
                            <input class="form-control" placeholder="Re-enter New Password" name="passconf" type="password" required>
                        </div>
                        <button class="btn btn-primary form-control">ยืนยัน</button>
                    </form>
                </div>
            </div>
        </div>
      </div>
      </div>   

              <div class="box-footer">
             </div>
          </div>
          <!-- /.box -->
		</div>

    </div>
    </section>
    <!-- /.content -->
  </div>           

  <!-- /.content-wrapper -->