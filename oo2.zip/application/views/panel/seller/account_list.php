<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       ประวัติการเช่าทั้งหมด
      </h1>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-home"></i> หน้าหลัก</a></li>
        <li class="active">ประวัติการเช่า</li>
    </ol>
    </section>

			    <!-- Main content -->
  		  <section class="content">
				<br><div class="row">
                    <div class="col-md-2 text-center">
                        <label class="label label-success">Fast Data Transfer</label>
                        <label class="label label-warning">High Speed Servers</label>
                        <label class="label label-info">Hide Your IP</label>
                        <label class="label label-primary">Premium VPN Server</label>
                        <label class="label label-warning">Worldwide Servers</label>
                        <label class="label label-success">Internet Privacy</label>
                        <label class="label label-info">Exclusive Secure Shell</label>
                        <label class="label label-success">Security Solutions</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 text-center">
                        <label class="label label-danger">No DDOS</label>
                        <label class="label label-danger">No Hacking</label>
                        <label class="label label-danger">No Carding</label>
                        <label class="label label-danger">No Spamm</label>
                        <label class="label label-danger">No Torrent</label>
                        <label class="label label-danger">No Fraud</label>
                        <label class="label label-danger">No Repost</label>                        
                    </div>
                </div>
			    <br>

    <div class="row">
       <div class="col-sm-6 col-md-4 col-lg-3">    
        <div class="box box-widget widget-user">
           <div class="widget-user-header bg-black" style="background: url('<?php echo  base_url('asset/img/photo.jpeg') ?>') center center;">
              <h3 class="widget-user-username"><i class="fa fa-user-circle"></i> ประวัติการเช่าทั้งหมด</h3>
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="<?php echo  base_url('asset/img/user-128x128.png') ?>" alt="User Avatar">
            </div>
                          
	    <div class="description-block">
            <span class="description-text"><span class="label label-danger"> รายละเอียด </span></span>
         </div>
        
              
                <div class="box-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>     
                                    <th>ชื่อบัญชี</th>                                   
                                    <th>เซิร์ฟเวอร์</th>
                                    <th>วันที่เช่า</th>
                                    <th>วันหมด</th>
                                    <th>ราคา</th>
                                    <th>ลบ</th>
                                    </tr>
                               </thead>
                            <tbody>
                                <?php if(!empty($account)):?>
										<?php $jumlah=0; $counter=0; ?>
                                        <?php foreach ($account as $row): ?>
											<?php $counter++; ?>
                                            <tr>
                        
                                                <td><?php echo  $row['username'] ?></td>
                                                <td><?php echo  $row['hostname']?></td>
                                                <td><?php echo  $row['created_at']?></td>
                                                <td><?php echo  date("d-m-Y",strtotime("+".$row['expired_at']." days", time() ) )?></td>
                                                <td><?php echo  $row['price']?></td>
                                                <td>
                                                    <a href="<?php echo  base_url('seller/delet_account/'. $row['id'])?>" class="btn btn-danger"><span class="fa fa-trash-o fa-sm"></span></a>
                                                </td>
                                             </tr>
                                             <?php $jumlah = $jumlah + $row['price']; ?>
                                       <?php endforeach; ?>
                                    <?php else: ?>
                                   
                                        <tr>
                                            <td class="text-muted text-center" colspan="6"> คุณยังไม่ได้เช่า</td>
                                        </tr>
                                   <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
				<div class="box-footer"><B> <?php if (isset($counter)) {echo 'ทั้งหมด : '. $counter; } ?> บัญชี | <?php if (isset($jumlah)) {echo 'รวมเงินที่เช่า : '. $jumlah; } ?> บาท <B></div>
            </div>
        </div>
    </div>            
 </section>  
</div>
  <!-- /.content-wrapper -->