<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       ระบบเติมเงิน อัตโนมัติ
      </h1>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
        <li class="active">เติมเงิน</li>
    </ol>
    </section>

			  <br><div class="row">
                    <div class="col-md-2 text-center">
                        <label class="label label-success">Fast Data Transfer</label>
                        <label class="label label-warning">High Speed Servers</label>
                        <label class="label label-info">Hide Your IP</label>
                        <label class="label label-primary">Premium VPN Server</label>
                        <label class="label label-warning">Worldwide Servers</label>
                        <label class="label label-success">Internet Privacy</label>
                        <label class="label label-info">Exclusive Secure Shell</label>
                        <label class="label label-success">Security Solutions</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 text-center">
                        <label class="label label-danger">No DDOS</label>
                        <label class="label label-danger">No Hacking</label>
                        <label class="label label-danger">No Carding</label>
                        <label class="label label-danger">No Spamm</label>
                        <label class="label label-danger">No Torrent</label>
                        <label class="label label-danger">No Fraud</label>
                        <label class="label label-danger">No Repost</label>                        
                    </div>
                </div>
			    <p></p>

    <!-- Main content -->
    <section class="content">
    <div class="row">
		<center>
        <button style="font-size: 16px;" class="badge bg-blue btn-outline-danger my-2 my-lg-5" type="button"><span class="fa fa-btc"></span>  ยอดเงินคงเหลือ : <?php echo  $user->saldo ?> บาท</button><br><br>
		</center>
        <div class="col-lg-12">
        	<div class="box box-widget widget-user">
        	<div class="box-tools pull-right">
                 <button class="btn btn-xs btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
             </div>
             
           <div class="widget-user-header bg-black" style="background: url('<?php echo  base_url('asset/img/photo.jpeg') ?>') center center;">
              <h3 class="widget-user-username">TRUE MONEY (บัตรทรูมันนี่)</h3>
              <h5 class="widget-user-desc"></h5>
              
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="<?php echo  base_url('asset/img/user.png') ?>" alt="User Avatar">
            </div>
             
             <div class="box-body">
                    <table class="table">
                        <tr>
						<br> <center><img src="<?php echo  base_url('asset/img/tmoney.png') ?>"><br></center> <br>
								 <center><h5> เติมผ่านบริการ true money มีค่าทำเนียม 14% ตัวอย่าง เติม 50 บาท จะได้ 43 บาท <h5></center>
					<div class="form-group">
						<label for="tmn_password">บัตรเงินสดทรูมันนี่</label>
						<input name="tmn_password" type="number" id="tmn_password" maxlength="14" class="form-control" placeholder="กรอกบัตรทรูมันนี่ 14 หลัก">
				 <input name="ref1" type="hidden" value="<?php echo  $user->id ?>" id="ref1">
				 <input name="ref2" type="hidden" value="<?php echo  $user->username ?>" id="ref2">
				 <input name="ref2" type="hidden" value="<?php echo  $user->email ?>" id="ref2">    
					</div>				
					<button type="button" class="btn btn-success btn-block btn-main" onclick="submit_tmnc()">ยืนยัน</button>
					 <label class="label label-danger" style="font-size: 11px;">ขณะเติมเงินโปรดรอ อย่ารีเฟรชหรือปิดหน้าจอน่ะครับ</label>
								 
					 </tr>
                    </table>
	       		</div>       
        	</div>
       </div>
      
       
	</div>                
 </section>  
</div>

<!-- แก้ไขตรง UID เพื่อเปลี่ยนเป็น UID Tmtopup ของท่านเอง  -->
<script type="text/javascript" src='https://www.tmtopup.com/topup/3rdTopup.php?uid=214380'></script>

  <!-- /.content-wrapper -->