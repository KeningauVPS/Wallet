<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       ไฟล์สำหรับใช้งาน VPN SSH
      </h1>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-home"></i> หน้าหลัก</a></li>
        <li class="active">CONFIG VPN SSH</li>
    </ol>
    </section>

						<br><div class="row">
                    <div class="col-md-2 text-center">
                        <label class="label label-success">Fast Data Transfer</label>
                        <label class="label label-warning">High Speed Servers</label>
                        <label class="label label-info">Hide Your IP</label>
                        <label class="label label-primary">Premium VPN Server</label>
                        <label class="label label-warning">Worldwide Servers</label>
                        <label class="label label-success">Internet Privacy</label>
                        <label class="label label-info">Exclusive Secure Shell</label>
                        <label class="label label-success">Security Solutions</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 text-center">
                        <label class="label label-danger">No DDOS</label>
                        <label class="label label-danger">No Hacking</label>
                        <label class="label label-danger">No Carding</label>
                        <label class="label label-danger">No Spamm</label>
                        <label class="label label-danger">No Torrent</label>
                        <label class="label label-danger">No Fraud</label>
                        <label class="label label-danger">No Repost</label>                        
                    </div>
                </div>
			    <p></p>

    <!-- Main content -->
    
  <section class="content">   
       <div class="col-sm-6 col-md-4 col-lg-3">    
        <div class="box box-widget widget-user">
           <div class="widget-user-header bg-black" style="background: url('<?php echo  base_url('asset/img/s1.jpeg') ?>') center center;">
              <h3 class="widget-user-username"><B>ไฟล์สำหรับเชื่อมต่อ<B></h3>
              <h4 class="widget-user-desc"><B>แอพ HTTP INJECTOR<B></h4>
              <p>แอพ OpenVPN</p>
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="<?php echo  base_url('asset/img/user.png') ?>" alt="User Avatar">
            </div>
                  
       <div class="box-footer no-padding">
      	<div class="description-block"><br><br>
            <span class="description-text"><span style="font-size: 16px;"  class="badge bg-red">รายละเอียด</span></span>
         </div>
         
          <ul class="nav nav-stacked">
              <div class="panel-body">
                    <table class="table width="450">
                        <center>
                        <tr>
                            <td><span class="label label-success"><i class="fa fa-cloud-download"></i> SERVER </span></td><td><span class="label label-warning"> <i class="fa fa-rocket"></i> HTTP INJECTOR</span></td></td><td><span class="label label-info"><i class="fa fa-send"></i> OPEN VPN </span></td></td>                            
                        </tr>
                        <tr>
                            <td><b>SINGAPORE</b></td><td><b><a href="/web/http/SG-1.LOWCLASS.ehi" class="btn btn-sm btn-danger"><i class="fa fa-rocket"></i> SSH SG1</a><b></td><td><b><a href="/web/http/SG-1.LOWCLASS.ehi" class="btn btn-sm btn-danger"><i class="fa fa-send"></i> VPN SG1</a><b></td>
                        </tr>
                        <tr>
                            <td><b>SINGAPORE</b></td><td><b><a href="/web/http/SG-2.LOWCLASS.ehi" class="btn btn-sm btn-info"><i class="fa fa-rocket"></i> SSH SG2</a><b></td><td><b><a href="/web/http/SG-2.LOWCLASS.ehi" class="btn btn-sm btn-info"><i class="fa fa-send"></i> VPN SG2</a><b></td>
                        </tr>
                            <td><b>THAILAND 2</b></td><td><b><a href="/web/http/TH-2.LOWCLASS.ehi " class="btn btn-sm btn-success"><i class="fa fa-rocket"></i> SSH TH2</a><b></td><td><b><a href="/web/http/TH-2.LOWCLASS.ehi " class="btn btn-sm btn-success btn-round"><i class="fa fa-send"></i> VPN TH2</a><b></td>
                        </tr>
                            <td><b>THAILAND 3</b></td><td><b><a href="/web/http/TH-3.LOWCLASS.ehi " class="btn btn-sm btn-primary btn-round"><i class="fa fa-rocket"></i> SSH TH3</a><b></td><td><b><a href="/web/http/TH-3.LOWCLASS.ehi " class="btn btn-sm btn-primary btn-round"><i class="fa fa-send"></i> VPN TH3</a><b></td>
                        </tr>
                        
						      </center> 
                   	    </table>
        			  </div>
        			</ul>
				  </div>
 	        </div>
 		
 
       </section>      
  </div>