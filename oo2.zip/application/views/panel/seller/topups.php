<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       ระบบเติมเงิน อัตโนมัติ
      </h1>
    <ol class="breadcrumb">
        <li><a href="/home"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
        <li class="active">เติมเงิน</li>
    </ol>
    </section>

						<br><div class="row">
                    <div class="col-md-2 text-center">
                        <label class="label label-success">Fast Data Transfer</label>
                        <label class="label label-warning">High Speed Servers</label>
                        <label class="label label-info">Hide Your IP</label>
                        <label class="label label-primary">Premium VPN Server</label>
                        <label class="label label-warning">Worldwide Servers</label>
                        <label class="label label-success">Internet Privacy</label>
                        <label class="label label-info">Exclusive Secure Shell</label>
                        <label class="label label-success">Security Solutions</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 text-center">
                        <label class="label label-danger">No DDOS</label>
                        <label class="label label-danger">No Hacking</label>
                        <label class="label label-danger">No Carding</label>
                        <label class="label label-danger">No Spamm</label>
                        <label class="label label-danger">No Torrent</label>
                        <label class="label label-danger">No Fraud</label>
                        <label class="label label-danger">No Repost</label>                        
                    </div>
                </div>
			    <p></p>

    <!-- Main content -->
    <section class="content">
    <button style="font-size: 16px;" class="badge bg-red btn-outline-danger my-2 my-lg-5" type="button"><span class="fa fa-btc"></span>  ยอดเงินคงเหลือ : <?php echo  $user->saldo ?> บาท</button>
	       
	<div class="row">
        <div class="col-lg-12">
        	<div class="box box-widget widget-user">
        	<div class="box-tools pull-right">
                 <button class="btn btn-xs btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
             </div>
             
           <div class="widget-user-header bg-black" style="background: url('<?php echo  base_url('asset/img/photo.jpeg') ?>') center center;">
              <h3 class="widget-user-username">TRUE WALLET (ทรูวอเล็ต)</h3>
              <h5 class="widget-user-desc"></h5>
              
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="<?php echo  base_url('asset/img/user.png') ?>" alt="User Avatar">
            </div>
             
             <div class="box-body">
                    <table class="table">
                    <tr>
					<br><center><h5> เติมผ่านบริการ true wallet<p> เติม 10 บาท จะได้ 10 บาท ตามปกติ<h5></center>
					<center><img src="<?php echo  base_url('asset/img/twallet.png') ?>"><br></center> <br>
                    <form method="post" action="https://www.twpay.co/websrc?cmd=express-checkout&merchant=N25S001032&userid=<?php echo  $user->id ?>&amount=">
						<label for="amount">จำนวนเงิน </label>
							<input class="form-control" placeholder="ใส่จำนวนที่ต้องการ" name="amount" type="number" required>							
					<small class="text-muted">ขั้นต่ำ 10 บาท</small>
					 <br> <div class="form-group">						 
			 			<button type="submit" class="btn btn-success btn-block btn-main btn-round">ยืนยัน</button>         				
						<label class="label label-danger" style="font-size: 11px;">ขณะเติมเงินโปรดรอ อย่ารีเฟรชหรือปิดหน้าจอน่ะครับ</label>
								 <h5>ลืมรหัสผ่าน true wallet?<b><a href="https://wallet.truemoney.com/user/help"> กดตรงนี้</a></b></h5>
								 
                        </tr>
                    </table>
                  </div>
             </form>
		</div>      
       
	</div>                
 </section>  
</div>
  <!-- /.content-wrapper -->