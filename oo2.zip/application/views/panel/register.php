<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <title>LOWCLASS VPN SSH</title>

    <!-- Bootstrap core CSS -->
    <link href="../assets/css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="../assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
        
    <!-- Custom styles for this template -->
    <link href="../assets/css/style.css" rel="stylesheet">
    <link href="../assets/css/style-responsive.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->

	  <div class="container">
	
		<div class="col-lg-10">
			
				<div class="panel-heading"></div>
				<div class="panel-body">
				<?php if (validation_errors()) : ?>
			<div class="col-md-12">
				<div class="alert alert-danger" role="alert">
					<?php echo  validation_errors() ?>
				</div>
			</div>
		<?php endif; ?>
		<?php if (isset($error)) : ?>
			<div class="col-md-12">
				<div class="alert alert-danger" role="alert">
					<?php echo  $error ?>
				</div>
			</div>
		<?php endif; ?>
		<div class="col-md-12">
			<div class="page-header text-center">
				<span style="font-size: 25px;" class="label label-info">สมัครบัญชี</span>
			</div>
			<?php echo  form_open() ?>
				<div class="form-group">
					<label for="username">ชื่อบัญชี</label>
					<input type="text" class="form-control" id="username" name="username" placeholder="อย่างน้อย 4 ตัว อักษร">
					
				</div>
				<div class="form-group">
					<label for="email">Email</label>
					<input type="email" class="form-control" id="email" name="email" placeholder="Email ของคุณ">
					
				</div>
				<div class="form-group">
					<label for="password">รหัสผ่าน</label>
					<input type="password" class="form-control" id="password" name="password" placeholder="อย่างน้อย 6 ตัว อักษร">
					
				</div>
				<div class="form-group">
					<label for="password_confirm">ยืนยันรหัสผ่าน</label>
					<input type="password" class="form-control" id="password_confirm" name="password_confirm" placeholder="ยืนยันรหัส">
					
				</div>
				<div class="form-group">
					<button class="btn btn-theme btn-block" type="submit"><i class="fa fa-lock"></i> ยืนยันการสมัคร</button>
				</div>
				<div class="registration">
		                มีบัญชีอยู่แล้ว?<B/>
		                <a href="<?php echo  base_url('login/login') ?>"> Login </a>		                    
		                </a>
		            </div>
		            </div>
			</form>
		</div>
				</div>
				
			</div>
		</div>
	</div><!-- .row -->
</div><!-- .container -->

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="../assets/js/jquery.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>

    <!--BACKSTRETCH-->
    <!-- You can use an image of whatever size. This script will stretch to fit in any screen size.-->
    <script type="text/javascript" src="../assets/js/jquery.backstretch.min.js"></script>
    <script>
        $.backstretch("../assets/img/login-bg.jpg", {speed:1000});
    </script>


  </body>
</html>