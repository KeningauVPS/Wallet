<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8"/>
		  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
		<meta name="description" content=""/>
		<meta name="keywords" content=""/>
		<meta name="author" content=""/>
		<title>พี่เทพ VPN SSH</title>
		
		<link href="<?php echo  base_url('asset/css/bootstrap.min.css')?>" rel="stylesheet"/>
		<link href="<?php echo  base_url('asset/css/bootstrap.css')?>" rel="stylesheet"/>
		<link href="<?php echo  base_url('asset/dist/css/AdminLTE.min.css')?>" rel="stylesheet"/>
		<link href="<?php echo  base_url('asset/dist/css/skins/_all-skins.min.css')?>" rel="stylesheet"/>
		<link href="<?php echo  base_url('asset/css/bootstrap-dialog.min.css')?>" rel="stylesheet"/>
		<link href="<?php echo  base_url('asset/css/material-kit.css')?>" rel="stylesheet"/>
		
		<!-- Custom Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link href="<?php echo  base_url('asset/font-awesome/css/font-awesome.min.css')?>" rel="stylesheet"/>
    <!-- Plugin CSS -->
    <link href="<?php echo  base_url('asset/css/animate.min.css" type="text/css')?>" rel="stylesheet"/>
    <!-- Custom CSS -->
    <link href="<?php echo  base_url('asset/css/creative.css" type="text/css')?>" rel="stylesheet"/>
  	
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
		<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
		<!--[if lt IE 9]>
		<script src="<?php echo  base_url('asset/js/html5shiv.js');?>"></script>
		<script src="<?php echo  base_url('asset/js/respond.min.js');?>"></script>
		<![endif]-->
		<link rel="shortcut icon" href="<?php echo  base_url('shortcut icon" href="/favicon.ico" type="image/x-icon')?>"/>
  <link rel="shortcut icon" href="<?php echo  base_url('apple-touch-icon" href="/apple-touch-icon.png')?>"/>
  <link rel="shortcut icon" href="<?php echo  base_url('apple-touch-icon" sizes="57x57" href="/apple-touch-icon-57x57.png')?>"/>
  <link rel="shortcut icon" href="<?php echo  base_url('apple-touch-icon" sizes="72x72" href="/apple-touch-icon-72x72.png')?>"/>
  <link rel="shortcut icon" href="<?php echo  base_url('apple-touch-icon" sizes="76x76" href="/apple-touch-icon-76x76.png')?>"/>
  <link rel="shortcut icon" href="<?php echo  base_url('apple-touch-icon" sizes="114x114" href="/apple-touch-icon-114x114.png')?>"/>
  <link rel="shortcut icon" href="<?php echo  base_url('apple-touch-icon" sizes="120x120" href="/apple-touch-icon-120x120.png')?>"/>
  <link rel="shortcut icon" href="<?php echo  base_url('apple-touch-icon" sizes="144x144" href="/apple-touch-icon-144x144.png')?>"/>
  <link rel="shortcut icon" href="<?php echo  base_url('apple-touch-icon" sizes="152x152" href="/apple-touch-icon-152x152.png')?>"/>
  <link rel="shortcut icon" href="<?php echo  base_url('apple-touch-icon" sizes="180x180" href="/apple-touch-icon-180x180.png')?>"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
</head>
<body class="hold-transition skin-green fixed sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="<?php echo  base_url('main/'.$_SESSION['username'].' ')?>" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      	
      <?php foreach ($this->user_model->view_asset() as $row): ?>
      	<?php if (empty($row['rekening'])):?>
      	<?php if (empty($row['bank'])):?>
      	<?php if (empty($row['pemilik'])):?>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><B> <?php echo  $row['webname']?> </B></span>
    </a>
    <?php endif;?>
    <?php endif;?>
    	<?php endif;?>
			 <?php endforeach; ?>
    
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>Menu
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
			<li>
           <a href="<?php echo  base_url('main/'.str_replace(' ','-',$_SESSION['username']).'/topups') ?>">เติมเงิน</a>
          </li>
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">			 
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"> 					 
			<span class="fa fa-user" alt="User Image"> 
              
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="<?php echo  base_url('asset/img/user-128x128.png')?>" class="img-circle" alt="User Image">
				<?php if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true): ?>
					<p><a href="#"><i class="fa fa-circle text-success">STATUS</i> <?php if ($_SESSION['is_admin']) { echo "ADMIN"; } else {echo "MEMBER"; } ?></a></p>
              <p>ชื่อบัญชี <?php echo  $_SESSION['username'] ?></p>             
              </li>
              <?php endif; ?>
             
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="<?php echo  base_url('main/'.$_SESSION['username'].'/setting')?>" class="btn btn-default btn-flat"> เปลี่ยนรหัส</a>
                </div>
                <div class="pull-right">
                  <a href="<?php echo  base_url('main/'.$_SESSION['username'].'/logout')?>" class="btn btn-default btn-flat" > ออกจากระบบ</a>
                </div>
              </li>
            </ul>
          </li>
		  <!-- Control Sidebar Toggle Button -->          
			
      </div>
    </nav>
  </header>
  
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo  base_url('asset/img/user-128x128.png')?>" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
      		<?php if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true): ?>
              <p><?php echo  $_SESSION['username'] ?></p>
               <a href="#"><i class="fa fa-circle text-success"></i> <?php if ($_SESSION['is_admin']) { echo "ADMIN"; } else {echo "MEMBER"; } ?></a>           
                	
        </div>
      </div>
		
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="header">เมนู</li>
        <li><a href="<?php echo  base_url('main/'.$_SESSION['username'].' ')?>"><i class="fa fa-home"></i><span>HOME</span></a></li>
        <?php if ($_SESSION['is_admin']): ?>
      <li class="treeview">
          <a href="#">
            <i class="fa fa-mixcloud"></i> <span>Server VPN SSH</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>          
          <ul class="treeview-menu">
            <li><a href="<?php echo  base_url('main/administrator/'.$_SESSION['username'].'/server') ?>"><i class="fa fa-cloud-upload"></i> รายชื่อ Server</a></li>
            <li><a href="<?php echo  base_url('main/administrator/'.str_replace(' ','-',$_SESSION['username']).'/addserver') ?>"><i class="fa fa-cloud-download"></i> เพิ่ม Server</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-group"></i> <span>รายชื่อสมาชิก</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo  base_url('main/checkuser/'.$_SESSION['username']) ?>"><i class="fa fa-user-md"></i> สมาชิกทั้งหมด</a></li>
            <li><a href="<?php echo  base_url('main/admin/register/'.$_SESSION['username']) ?>"><i class="fa fa-user-plus"></i> เพิ่มสมาชิก</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-pie-chart"></i> <span>ตั้งชื่อเว็บ</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo  base_url('admin/webname')?>"><i class="fa fa-leanpub"></i> ตั้งชื่อเว็บ</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-bullhorn"></i> <span>กิจกรรมและข่าวสาร</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo  base_url('admin/event')?>"><i class="fa fa-bar-chart"></i> จัดกิจกรรม</a></li>
          </ul>
        </li>     
        <li class="treeview">
          <a href="#">
            <i class="fa fa-btc"></i> <span>ตั้งค่าการเติมเงิน</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo  base_url('admin/wallet')?>"><i class="fa fa-money"></i> ข้อมูลสำหรับเติมเงิน</a></li>
          </ul>
        </li>
		</true>
		<?php else: ?>
      <li class="treeview">
          <a href="#">
            <i class="fa fa-cloud"></i> <span>SERVER VPN SSH</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo  base_url('main/'.$_SESSION['username'].'/server') ?>"><i class="fa fa-rocket"></i> เซิร์ฟเวอร์ทั้งหมด</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-medium"></i> <span>เติมเงิน</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo  base_url('main/'.$_SESSION['username'].'/topup') ?>"><i class="fa fa-btc"></i> TRUE MONEY (อัตโนมัติ)</a></li>
            <li><a href="<?php echo  base_url('main/'.$_SESSION['username'].'/topups') ?>"><i class="fa fa-money"></i> TRUE WALLET (อัตโนมัติ)</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-user"></i> <span>เช็คบัญชีที่เช่า</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo  base_url('main/checkuser/'.$_SESSION['username']) ?>"><i class="fa fa-user"></i> บัญชีที่เช่า</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-send"></i> <span>ไฟล์ CONFIG</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo  base_url('main/'.$_SESSION['username'].'/config')?>"><i class="fa fa-send-o"></i> สำหรับ VPN</a></li>
            <li><a href="<?php echo  base_url('main/'.$_SESSION['username'].'/config')?>"><i class="fa fa-terminal"></i> สำหรับ SSH</a></li>
          </ul>
        </li>
		<?php endif; ?>
			
            <?php endif; ?>


        <li class="header">เพิ่มเติม</li>
		<li class="treeview">
          <a href="#">
            <i class="glyphicon glyphicon-phone"></i>
				<span>ติดต่อข้อมูลเพิ่มเติม.</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
        <li><a href="http://facebook.com/beerwaiting"><i class="fa fa-facebook"></i> <span>Facebook</span></a></li>
        <li><a href="https://m.me/beerwaiting/"><i class="fa fa-twitch"></i> <span>FB Messenger</span></a></li>
        <li><a href="https://www.facebook.com/groups/143457819538014/"><i class="fa fa-facebook-official"></i> <span>FB Groups</span></a></li>       
          </ul>                        
              
        <li><a href="<?php echo  base_url('main/'.$_SESSION['username'].'/profile')?>"><i class="fa fa-group"></i> <span>โปรไฟล์</span></a></li>
        <li><a href="<?php echo  base_url('main/'.$_SESSION['username'].'/setting')?>"><i class="fa fa-cog"></i> <span>ตั้งค่า</span></a></li>
        <li><a href="<?php echo  base_url('main/'.$_SESSION['username'].'/logout')?>"><i class="fa fa-sign-out"></i> <span>ออกจากระบบ</span></a></li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>
</body>
</html>