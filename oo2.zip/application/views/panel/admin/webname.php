<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Server VPN SSH
      </h1>
    <ol class="breadcrumb">
        <li><a href="/home"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
        <li class="active">เซิร์ฟเวอร์ทั้งหมด</li>
    </ol>
    </section>
    		<section class="content">
   			 <div class="row">
                    <div class="col-md-12 text-center">
                        <label class="label label-success">Fast Data Transfer</label>
                        <label class="label label-warning">High Speed Servers</label>
                        <label class="label label-info">Hide Your IP</label>
                        <label class="label label-primary">Premium VPN Server</label>
                        <label class="label label-warning">Worldwide Servers</label>
                        <label class="label label-success">Internet Privacy</label>
                        <label class="label label-info">Exclusive Secure Shell</label>
                        <label class="label label-primary">Security Solutions</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 text-center">
                        <label class="label label-danger">No DDOS</label>
                        <label class="label label-danger">No BUG</label>
                        <label class="label label-danger">No Hacking</label>
                        <label class="label label-danger">No Carding</label>
                        <label class="label label-danger">No Spamm</label>
                        <label class="label label-danger">No Torrent</label>
                        <label class="label label-danger">No Fraud</label>
                        <label class="label label-danger">No Error</label>
                        <label class="label label-danger">No Repost</label>
                    </div>
                </div>
			<br>
       
    <div class="row">
    	<div class="col-lg-6">
          <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 class="panel-title">แก้ไขชื่อเว็บไซต์</h3>
                </div>
                
			  <?php if (isset($message)) {echo $message;} ?>
			  <?php if (validation_errors()) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?php echo  validation_errors() ?></div>
					</div>
					<?php endif; ?>
					<?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?php echo  $error ?></div>
					</div>
			   <?php endif;?>
                <?php echo  form_open() ?>
                <div class="panel-body">
                   <input type="text" name="webname" class="form-control" id="webname" placeholder="ใส่ชื่อที่ต้องการ"/>
                       </div>
                       <div class="form-group">
						<input type="submit" class="btn btn-md btn-block btn-warning" value="ยืนยัน"/>
					</div>
                 </form>
            </div>
        </div>
        
         <div class="col-lg-6">   
				<?php if (!empty($asset)):?>
					<h4 class="page-header">ชื่อเว็บที่ตั้งไว้</h4>
					<div class="table-responsive"><table class="table table-hover">
						<thead>
							<tr>
							<th>Web Name</th>
							</tr>
                        </thead>
                        <tbody>
						<?php foreach ($asset as $row): ?>
							<?php if (empty($row['rekening'])):?>
                          	<?php if (empty($row['bank'])):?>
                             	<?php if (empty($row['pemilik'])):?>
							<tr>
								<td><a href="<?php echo base_url('admin/del_req/'.$row['id'])?>">Del</a></td>
								<td><?php echo  $row['webname']?></td>
							</tr>
									<?php endif;?>
							    <?php endif;?>
    						<?php endif;?>
						<?php endforeach; ?>
						</tbody>
					</table></div>
					<?php else: ?>
						<h4 class="page-header">ยังไม่ได้ตั้งไว้</h4>
				<?php endif; ?>
			</div>
		</div>
    </div>
    
      </section>
</div>