<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Server VPN SSH
      </h1>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-home"></i> หน้าหลัก</a></li>
        <li class="active">เซิร์ฟเวอร์ทั้งหมด</li>
    </ol>
    </section>
 
        <section class="content">   		
   			 <div class="row">
                    <div class="col-md-12 text-center">
                        <label class="label label-success">Fast Data Transfer</label>
                        <label class="label label-warning">High Speed Servers</label>
                        <label class="label label-info">Hide Your IP</label>
                        <label class="label label-primary">Premium VPN Server</label>
                        <label class="label label-warning">Worldwide Servers</label>
                        <label class="label label-success">Internet Privacy</label>
                        <label class="label label-info">Exclusive Secure Shell</label>
                        <label class="label label-primary">Security Solutions</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 text-center">
                        <label class="label label-danger">No DDOS</label>
                        <label class="label label-danger">No Hacking</label>
                        <label class="label label-danger">No Carding</label>
                        <label class="label label-danger">No Spamm</label>
                        <label class="label label-danger">No Torrent</label>
                        <label class="label label-danger">No Fraud</label>
                        <label class="label label-danger">No Error</label>
                        <label class="label label-danger">No Repost</label>
                    </div>
                </div>
			<br>
   
    <div class="row">
            <div class="col-lg-12">
                <?php if (isset($_SESSION['is_admin'])): ?>
                <a href="<?php echo  base_url('main/administrator/'.str_replace(' ','-',$_SESSION['username']).'/addserver') ?>" class="btn btn-primary pull-right"><i class="fa fa-plus fa-fw"></i> เพิ่มเซิร์ฟเวอร์ </a>
                <?php endif; ?>           
    <br><br><br>
    <div class="row">
            <div class="col-lg-12">
                <?php if (isset($message)) { echo $message;} ?>
            </div>
        <?php foreach($server as $row): ?>
            <div class="col-sm-6 col-md-4 col-lg-3">
                <div class="panel panel-info">					 
                    <div class="panel-heading">                      
												<div class="panel-title"><b><?php echo  $row['ServerName']?></b></div>
							<span clas="pull-right">
							<?php if ($row['Status']): ?>
								<a class="btn btn-success btn-sm pull-right" href="<?php echo  base_url('main/administrator/edit/'.str_replace(' ','-',$row['ServerName']).'/'.$row['Id'].'/lock' ) ?>"><i class="fa fa-unlock"></i> เปิดบริการ</a>
								<?php else: ?>
								<a class="btn btn-info btn-sm pull-right" href="<?php echo  base_url('main/administrator/edit/'.str_replace(' ','-',$row['ServerName']).'/'.$row['Id'].'/unlock' ) ?>"><i class="fa fa-lock"></i>  ปิดบริการ</a>
								<?php endif; ?>
							</span>
                    </div>
                    <div class="panel-body">
                    <table class="table table-condensed">
                        <tr>
                            <td>Server</td><td><?php echo  $row['Location']?></td>
                        </tr>
                        <tr>
                            <td>Host</td><td><?php echo  $row['HostName']?></td>
                        </tr>
                        <tr>
                            <td>ราคา</td><td><?php echo  $row['Price']?></td>
                        </tr>
                    </table>  
                    </div>
						
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <a href="<?php echo  base_url('main/administrator/edit/'.str_replace(' ','-',$row['ServerName']).'/'.$row['Id'])?>" class="btn btn-primary btn-sm"><i class="fa fa-edit fa-fw"></i> แก้ไข</a>
                        <a href="<?php echo  base_url('admin/usercheck/'.$row['Id']) ?>" class="btn btn-warning btn-sm"><i class="fa fa-group fa-fw"></i> เช็คบัญชี</a>
                        <a href="<?php echo  base_url('main/administrator/edit/'.str_replace(' ','-',$row['ServerName']).'/'.$row['Id'].'/del' ) ?>" class="btn btn-danger btn-sm hapus pull-right"> ลบ</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
      </section>
</div>