<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-home" aria-hidden="true"></i> Dashboard
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Timeline</li>
      </ol>
    </section>
    
    <section class="content">
        <div class="row">
        	<div class="col-md-6 col-md-offset-3">
							<div class="main main-raised">
			                    <div class="nav-align-center">
									<ul class="nav nav-pills nav-pills-info" role="tablist">
                                 <li>
									<a href="#event" role="tab" data-toggle="tab">
									กิจกรรมและแจ้งเตือน
									</a>
								</li>
                                    <li>
									<a href="#true" role="tab" data-toggle="tab">
									ข้อมูลโอนเงิน
									</a>
								</li>
                                    
                                    <li class="dropdown pull-left">
                                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                            เพิ่มเติม <span class="caret"></span>
                                        </a>
                                        <ul class="dropdown-menu">
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo  base_url('main/'.$_SESSION['username'].'/topups') ?>">เติมเงิน</a></li>
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="<?php echo  base_url('main/'.$_SESSION['username'].'/server') ?>">เช่าเซิร์ฟเวอร์</a></li>
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="https://m.me/BeerWaiting">ติดต่อ</a></li>
                                            <li role="presentation" class="divider"></li>
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="/home/config">ConfigVPN SSH</a></li>
                                    </ul>
                                </ul>
                                
                          <div class="tab-content text-center">
                             <div class="tab-pane active" id="event">
						      	<h3><b>กิจกรรมวันนี้</b></h3>	
                             		<?php foreach ($this->user_model->view_asset() as $row): ?>
									<?php if(!empty($row['rekening'])): ?>
									<h5><b><?php echo  $row['pemilik']?> </b></h5>
									<h5><?php echo  $row['bank']?>  </h5>
									<br><p>#หมายเหตุ: มีปัญหาด้านการใช้งาน  <b><a href="https://m.me/"<?php echo  $row['rekening']?>""> กดตรงนี้</a></b></p>
				
									<?php endif; ?>					
			  					 <?php endforeach; ?>
									
                              </div><!-- /.tab-pane -->   
                                 
				 <div class="tab-pane" id="true">
                    <h3><b>ข้อมูลสำหรับโอนเงิน</b></h3>								
                             		<?php foreach ($this->user_model->view_asset() as $row): ?>
									<?php if (!empty($row['nohp'])): ?>
								<h4><b>ชื่อ WALLET </b></h4>									
							<span style="font-size: 16px;" class="badge bg-maroon">	<?php echo  $row['pemilik']?></span>	
							<h4><b>เบอร์ WALLET</b></h4>	
							<span style="font-size: 18px;" class="badge bg-purple">	<?php echo  $row['nohp']?></span><br>
									<br><p>#หมายเหตุ: มีปัญหาด้านการใช้งาน  <b><a href="https://m.me/"<?php echo  $row['rekening']?>""> กดตรงนี้</a></b></p>
																							 
									<?php endif; ?>					
			  					 <?php endforeach; ?>
									
                                    </div><!-- /.tab-pane -->

					 
                                </div><!-- /.tab-content -->
                            </div><!-- nav-tabs-custom -->
                        </div><!-- /.col -->
                    </div> <!-- /.row -->
                    </div>
                    <!-- END CUSTOM TABS -->
 		<div class="row">                   	
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-maroon">
                <p>ยอดเงินคงเหลือ</p>
                  <h3><?php echo  $user -> saldo ?> บาท</h3>
                                               
                  <i class="ion ion-bag"></i>
                
                <a href="<?php echo  base_url('main/'.$_SESSION['username'].'/topups') ?>" class="small-box-footer">เติมเงิน <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-purple">
                <p>ชื่อบัญชี </p>
                  <h3><?php echo  $_SESSION['username'] ?><sup style="font-size: 20px"></sup></h3>                 
                                
                  <i class="ion ion-stats-bars"></i>
                
                <a href="<?php echo  base_url('main/'.$_SESSION['username'].'/profile') ?>" class="small-box-footer">Profile <i class="fa fa-arrow-circle-right"></i></a>
             			 </div>
            		</div>
            
				</div>
          </div>
    </section>
</div>